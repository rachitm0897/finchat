import { useMemo, useState } from "react";
import TickerPanel from "./components/TickerPanel";
import AnalysisSummaryPanel from "./components/AnalysisSummaryPanel";
import TrendChartsPanel from "./components/TrendChartsPanel";
import MetricsPanel from "./components/MetricsPanel";
import ComparisonPanel from "./components/ComparisonPanel";
import ComparisonVisualsPanel from "./components/ComparisonVisualsPanel";
import PeerRankingPanel from "./components/PeerRankingPanel";
import RankingVisualsPanel from "./components/RankingVisualsPanel";
import PortfolioActionsPanel from "./components/PortfolioActionsPanel";
import ValuationPanel from "./components/ValuationPanel";
import ScenarioPanel from "./components/ScenarioPanel";
import ReportExportPanel from "./components/ReportExportPanel";
import ChatPanel from "./components/ChatPanel";
import AppShell from "./components/layout/AppShell";
import SidebarNav, { type NavKey } from "./components/layout/SidebarNav";
import Topbar from "./components/layout/Topbar";
import WorkspacePage from "./components/workspace/WorkspacePage";
import SectionGrid from "./components/workspace/SectionGrid";
import BacktestingPanel from "./components/BackTestingPanel";
import "./styles.css";

function App() {
  const [ticker, setTicker] = useState("AAPL");
  const [refreshKey, setRefreshKey] = useState(0);
  const [activeView, setActiveView] = useState<NavKey>("dashboard");

  const appTitle = useMemo(() => {
    switch (activeView) {
      case "dashboard":
        return "MARKET MONITOR";
      case "analysis":
        return "COMPANY ANALYSIS";
      case "comparison":
        return "RELATIVE VALUE";
      case "chat":
        return "RESEARCH TERMINAL";
      case "backtesting":
        return "STRATEGY LAB";
      default:
        return "WORKSPACE";
    }
  }, [activeView]);

  const handleRefreshRequested = () => setRefreshKey((prev) => prev + 1);

  return (
    <AppShell
      sidebar={
        <SidebarNav
          activeView={activeView}
          onChange={setActiveView}
          ticker={ticker}
        />
      }
      topbar={
        <Topbar
          title={appTitle}
          ticker={ticker}
          onGoToDashboard={() => setActiveView("dashboard")}
          onRefresh={handleRefreshRequested}
        />
      }
    >
      <TickerPanel
        ticker={ticker}
        setTicker={setTicker}
        onRefreshRequested={handleRefreshRequested}
      />

      {activeView === "dashboard" && (
        <WorkspacePage
          title="Coverage overview"
          description="Live symbol context, summary flags, operating trend panels and latest computed metrics."
        >
          <SectionGrid columns="split">
            <AnalysisSummaryPanel ticker={ticker} refreshKey={refreshKey} />
            <TrendChartsPanel ticker={ticker} refreshKey={refreshKey} />
          </SectionGrid>
          <MetricsPanel ticker={ticker} refreshKey={refreshKey} />
        </WorkspacePage>
      )}

      {activeView === "analysis" && (
        <WorkspacePage
          title="Intrinsic value and scenario framing"
          description="Discounted cash flow output, planning assumptions, scenario rows and export controls."
        >
          <SectionGrid columns="split">
            <ValuationPanel ticker={ticker} />
            <ScenarioPanel ticker={ticker} />
          </SectionGrid>
          <ReportExportPanel ticker={ticker} />
        </WorkspacePage>
      )}

      {activeView === "comparison" && (
        <WorkspacePage
          title="Relative workbench"
          description="Peer comparison tables, ranking ladders, portfolio query tooling and relative visuals."
        >
          <ComparisonPanel ticker={ticker} />
          <SectionGrid columns="split">
            <ComparisonVisualsPanel />
            <PeerRankingPanel />
          </SectionGrid>
          <SectionGrid columns="split">
            <RankingVisualsPanel />
            <PortfolioActionsPanel />
          </SectionGrid>
        </WorkspacePage>
      )}

      {activeView === "chat" && (
        <WorkspacePage
          title="Research assistant"
          description="Compact analyst chat inside the platform. Useful, restrained, and not pretending to be the whole product."
        >
          <ChatPanel ticker={ticker} />
        </WorkspacePage>
      )}

      {activeView === "backtesting" && (
        <WorkspacePage
          title="Backtesting workbench"
          description="Run deterministic historical strategy tests, review drawdown and equity curves, and inspect saved runs."
        >
          <BacktestingPanel ticker={ticker} />
        </WorkspacePage>
      )}
    </AppShell>
  );
}

export default App;